<?php
include 'test.php';

$name = $_POST["name"];
$email = $_POST["email"];
$phone = $_POST["phone"];
$area = $_POST["area"];
$time = $_POST["time"];
$kidsNumber = $_POST["kidsNumber"];
$kid1Age = $_POST["kid1Age"];
$kid2Age = $_POST["kid2Age"];
$kid3Age = $_POST["kid3Age"];
$kid4Age = $_POST["kid4Age"];
$kid5Age = $_POST["kid5Age"];
$kid6Age = $_POST["kid6Age"];
$kid7Age = $_POST["kid7Age"];
$kid8Age = $_POST["kid8Age"];
$kid9Age = $_POST["kid9Age"];
$customerSource = $_POST["customerSource"];
$customerSourceOther = $_POST["customerSourceOther"];
$category = $_POST["category"];
$text = $_POST["message"];
$captcha = $_POST["gRecaptchaResponse"];

if (isset($captcha)) {
    $privatekey = "6Le0RxATAAAAANKTdmJhjzW0dZ088JPvfrv-EsPW";
    $url = 'https://www.google.com/recaptcha/api/siteverify';
    $data = array(
        'secret' => $privatekey,
        'response' => $captcha,
        'remoteip' => $_SERVER['REMOTE_ADDR']
    );

    $curlConfig = array(
        CURLOPT_URL => $url,
        CURLOPT_POST => true,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_POSTFIELDS => $data
    );

    $ch = curl_init();
    curl_setopt_array($ch, $curlConfig);
    $response = curl_exec($ch);
    curl_close($ch);
}

$jsonResponse = json_decode($response);

$msg = "
Name: $name
Email: $email
Phone: $phone

Area: $area
Time: $time

Category: $category
Number of Kids: $kidsNumber
Kids Age: $kid1Age, $kid2Age, $kid3Age, $kid4Age, $kid5Age, $kid6Age, $kid7Age, $kid8Age, $kid9Age

Heared of us from: $customerSource $customerSourceOther

Comments: $text
";

$to = "vukcuvardic@gmail.com";
$subject = "Website Contact Form";
$header = "Website Contact Form";

if ($jsonResponse->success == "true") {
    
}
    
else {
    mail($to, $subject, $msg, $header);
}

?>